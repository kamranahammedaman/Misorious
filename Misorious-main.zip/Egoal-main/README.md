# Egoal
Egoal - A Super Search Engine
